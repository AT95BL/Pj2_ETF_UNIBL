
public class Izuzetak extends Exception{
	public Izuzetak(){
		super();
	}
	
	public Izuzetak(String message){
		super(message);
	}
	
}