
public enum Zanr{
	FIKCIJA,
	NAUKA,
	ISTORIJA
}