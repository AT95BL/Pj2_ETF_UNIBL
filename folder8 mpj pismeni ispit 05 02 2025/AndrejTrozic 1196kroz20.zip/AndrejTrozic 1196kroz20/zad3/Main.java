
import java.util.*;
import java.util.stream.*;
import java.util.function.Function;

public class Main{
	
	public static void main(String[] args){
		Set<Knjiga> prvaGrupa = new HashSet<>();
		Set<Knjiga> drugaGrupa = new HashSet<>();
		
		Random random = new Random();
		
		for(int i=0; i < 20; i++){
			
			Knjiga knjiga1 = new Knjiga("naslov"+i, "autor"+i, i+1990, Zanr.FIKCIJA, 100+i);
			Knjiga knjiga2 = new Knjiga("naslov"+i, "autor"+i, i+1990, Zanr.NAUKA, 100+i);
			Knjiga knjiga3 = new Knjiga("naslov"+i, "autor"+i, i+1990, Zanr.ISTORIJA, 100+i);
			prvaGrupa.add(knjiga1);
			prvaGrupa.add(knjiga2);
			prvaGrupa.add(knjiga3);
			
			Knjiga knjiga4 = new Knjiga("naslov"+i, "autor"+i, i+2002, Zanr.FIKCIJA, 100+i);
			Knjiga knjiga5 = new Knjiga("naslov"+i, "autor"+i, i+2002, Zanr.NAUKA, 100+i);
			Knjiga knjiga6 = new Knjiga("naslov"+i, "autor"+i, i+2002, Zanr.ISTORIJA, 100+i);
			drugaGrupa.add(knjiga4);
			drugaGrupa.add(knjiga5);
			drugaGrupa.add(knjiga5);
		}
		
		prvaGrupa.stream().forEach(System.out::println);
		drugaGrupa.stream().forEach(System.out::println);
		prvaGrupa.addAll(drugaGrupa);
		drugaGrupa.clear();
		
		prvaGrupa.stream().collect(Collectors.groupingBy(Knjiga::getZanr)).forEach((zanr,knjige)->{ System.out.println("Zanr" + zanr); knjige.forEach(System.out::println); });
		
		prvaGrupa.stream().sorted(Comparator.comparingInt(Knjiga::getGodinaIzdanja)).forEach(System.out::println);
		
		/*
		Function<Knjiga, Integer> funkcija -> {
			int suma = prvaGrupa.stream().filter(k -> k.zanr == Zanr.NAUKA).mapToInt(Knjiga::getGodinaIzdanja).sum();
			return suma;
		};
		*/
		
		int suma = prvaGrupa.stream().filter(k -> k.zanr == Zanr.NAUKA).mapToInt(Knjiga::getGodinaIzdanja).sum();
		System.out.println("Suma: " + suma);
		
		prvaGrupa.stream().min(Comparator.comparingInt(Knjiga::getBrojStranica)).ifPresent(System.out::println);
		prvaGrupa.stream().max(Comparator.comparingInt(Knjiga::getBrojStranica)).ifPresent(System.out::println);
	}
}