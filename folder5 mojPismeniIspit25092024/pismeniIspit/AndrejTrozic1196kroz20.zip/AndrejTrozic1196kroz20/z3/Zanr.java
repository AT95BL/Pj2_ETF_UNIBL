
public enum Zanr{
	AKCIJA,
	DRAMA,
	KOMEDIJA,
	DOKUMENTARAC
}