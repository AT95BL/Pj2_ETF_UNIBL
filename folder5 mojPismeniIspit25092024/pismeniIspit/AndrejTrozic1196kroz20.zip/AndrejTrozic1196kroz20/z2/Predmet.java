
public class Predmet{
	/*
		Predmet
		- naziv String
		# sifra String
		+ unesiDetalje () void
		- sacuvajRezultate () boolean
	*/
	
	private String naziv;
	protected String sifra;
	public void unesiDetalje(){}
	private boolean sacuvajRezultate(){return false;}
}