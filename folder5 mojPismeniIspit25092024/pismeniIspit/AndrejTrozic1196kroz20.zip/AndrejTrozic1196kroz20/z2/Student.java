
import java.util.Date;

public class Student{
	/*
		Student
		- ime String
		- prezime String
		- indeks String
		+ brojac ime ??
		+ prijaviIspit (ispit String, datum Date) String
	*/
	private String ime;
	private String prezime;
	private String indeks;
	public  int brojac;
	public String prijaviIspit(String ispit, Date datum){ return "";}
	
}