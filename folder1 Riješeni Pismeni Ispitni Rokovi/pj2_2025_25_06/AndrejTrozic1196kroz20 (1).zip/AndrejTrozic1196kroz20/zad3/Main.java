
import java.util.*;
import java.util.stream.*;

public class Main{
	public static void main(String[] args){
		
		List<Uredjaj> listaUredjaja = new LinkedList<>();
		
		// kreiraj listu
		for(int i=0; i < 25; i++){
			Uredjaj uredjaj = new Uredjaj();
			listaUredjaja.add(uredjaj);
		}
		listaUredjaja.stream().forEach(System.out::println);
		
		// 1)
		listaUredjaja.stream().filter((t)-> t.vrsta == Vrsta.LAPTOP && t.tezina <= 2000).forEach(System.out::println);
		
		// 2)
		listaUredjaja.stream().sorted(Comparator.comparingDouble(Uredjaj::getCijena)).forEach(System.out::println);
		listaUredjaja.stream().sorted(Comparator.comparingDouble(Uredjaj::getTezina)).forEach(System.out::println);
		
		// 3)
		double cijena = listaUredjaja.stream().filter((t)->t.vrsta == Vrsta.TELEFON).mapToDouble(Uredjaj::getCijena).sum();
		System.out.println(cijena / listaUredjaja.size());
		
		// 4)
		listaUredjaja.stream().max(Comparator.comparingDouble(Uredjaj::getCijena)).ifPresent((t)->System.out.println(t));
		
		// 5)
		listaUredjaja.stream().distinct().forEach(System.out::println);
	}
}