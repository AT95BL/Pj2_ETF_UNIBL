
import java.util.*;

public class Uredjaj{
	public static int ID;
	int id;
	String naziv;
	String proizvodjac;
	int godinaProizvodnje;
	double tezina;
	double cijena;
	Vrsta vrsta;
	
	Random random = new Random();
	
	// Constructor
	public Uredjaj(){
		this.id = ID++;
		this.naziv = "Uredjaj" + this.id;
		this.proizvodjac = "Proizvodjac" + this.id;
		this.godinaProizvodnje = 2000 + this.id;
		this.tezina = this.id * 0.5;
		this.cijena = this.id * 10;
		
		this.vrsta = Vrsta.values()[random.nextInt(3)];
	}
	
	@Override
	public boolean equals(Object obj){
		if(obj.getClass() != this.getClass() || (obj == null))
			return false;
		else if(obj == this)
			return true;
		
		Uredjaj uredjaj = (Uredjaj)obj;
		return this.naziv.equals(uredjaj.naziv) &&  this.proizvodjac.equals(uredjaj.proizvodjac) && (this.godinaProizvodnje != uredjaj.godinaProizvodnje)
			&& this.tezina == uredjaj.tezina && this.cijena == uredjaj.cijena;
	}
	
	@Override
	public int hashCode(){
		return Objects.hash(this.naziv, this.proizvodjac, this.godinaProizvodnje, this.tezina, this.cijena);
	}
	
	@Override
	public String toString(){
		return this.naziv + " " + this.proizvodjac + " " + this.godinaProizvodnje + " " + this.tezina + " " + this.cijena + " " + this.vrsta;
	}
	
	public double getCijena(){
		return this.cijena;
	}
	
	public double getTezina(){
		return this.tezina;
	}
}