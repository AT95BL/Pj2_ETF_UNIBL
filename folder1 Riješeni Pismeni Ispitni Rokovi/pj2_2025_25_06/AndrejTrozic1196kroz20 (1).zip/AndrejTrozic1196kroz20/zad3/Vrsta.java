
public enum Vrsta{
	TELEFON,
	TABLET,
	LAPTOP
}