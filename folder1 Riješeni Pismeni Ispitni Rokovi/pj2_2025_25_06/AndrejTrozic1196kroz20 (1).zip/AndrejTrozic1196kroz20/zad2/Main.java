
import java.util.*;
import java.io.*;
import java.nio.file.*;


public class Main{
	public static void main(String[] args){
		
		Scanner scanner = new Scanner(System.in);
		String line = "";
		
		Path putanjaPocetnogDirektorijuma = null;
		System.out.println("Unesite putanju pocetnog direktorijuma: ");
		line = scanner.nextLine();
		putanjaPocetnogDirektorijuma = Paths.get(line);
		
		String trazenaRijec = "";
		System.out.println("Unesite trazenu rijec: ");
		trazenaRijec = scanner.nextLine();
		
		String opcija = "";
		System.out.println("Unesite opciju ");
		opcija = scanner.nextLine();
		
		FileFinder fileFinder = new FileFinder(putanjaPocetnogDirektorijuma, trazenaRijec, opcija);
		
		try{
			Files.walkFileTree(putanjaPocetnogDirektorijuma, fileFinder);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		fileFinder.rezultat();
	}
}