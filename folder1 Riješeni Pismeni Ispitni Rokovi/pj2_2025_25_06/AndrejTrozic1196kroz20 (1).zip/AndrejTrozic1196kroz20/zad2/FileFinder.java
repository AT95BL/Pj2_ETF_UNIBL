
import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.*;

public class FileFinder implements FileVisitor<Path>{
	
	Path putanjaPocetnogDirektorijuma;
	String trazenaRijec;
	String opcija;
	
	List<Path> listaMatch = new ArrayList<>();
	Map<Path, Integer> mapaMatch = new HashMap<>();
	List<Path> listaIgnore = new ArrayList<>();
	Map<Path, Integer> mapaIgnore = new HashMap<>();
	List<Path> listaLike = new ArrayList<>();
	Map<Path,Integer> mapaLike= new HashMap<>();
	
	// Constructor
	public FileFinder(Path putanjaPocetnogDirektorijuma, String trazenaRijec, String opcija){
		this.putanjaPocetnogDirektorijuma = putanjaPocetnogDirektorijuma;
		this.trazenaRijec = trazenaRijec;
		this.opcija = opcija;
	}
	
	@Override
	public FileVisitResult postVisitDirectory(Path dir, IOException ex)throws IOException{ 
		return FileVisitResult.CONTINUE; 
	}
	
	@Override
	public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes bfa)throws IOException{ 
		return FileVisitResult.CONTINUE; 
	}
	
	@Override
	public FileVisitResult visitFile(Path dir, BasicFileAttributes bfa)throws IOException{

		List<String> sveLinijeDatoteke = Files.readAllLines(dir);
		for(var linijaDatoteke:sveLinijeDatoteke){			
			String[] rijeciDatoteke = linijaDatoteke.split("");
			for(var rijec:rijeciDatoteke){
				if(rijec.equals(trazenaRijec)){
					listaMatch.add(dir);
					
					if(mapaMatch.get(dir) == null){
						mapaMatch.put(dir, 0);
					}else{
						int i = mapaMatch.get(dir);
						i++;
						mapaMatch.put(dir, i);
					}
					
				}else if(rijec.equalsIgnoreCase(trazenaRijec)){
					listaIgnore.add(dir);
					
					if(mapaIgnore.get(dir) == null){
						mapaMatch.put(dir, 0);
					}else{
						int i = mapaIgnore.get(dir);
						i++;
						mapaIgnore.put(dir, i);
					}
					
				}else if(linijaDatoteke.contains(trazenaRijec)){
					listaLike.add(dir);
					
					if(mapaLike.get(dir) == null){
						mapaMatch.put(dir, 0);
					}else{
						int i = mapaLike.get(dir);
						i++;
						mapaLike.put(dir, i);
					}
				}
			}
		}
		
		return FileVisitResult.CONTINUE; 
	}
	
	@Override
	public FileVisitResult visitFileFailed(Path dir, IOException ex)throws IOException{ 
		return FileVisitResult.CONTINUE; 
	}
	
	public void rezultat(){
		if(opcija.equalsIgnoreCase("MATCH_CASE")){
			for(var putanja: this.listaMatch){
				System.out.println(putanja);
			}
			
			for(Map.Entry<Path,Integer> entry: mapaMatch.entrySet()){
				System.out.println(entry.getKey() + " -- " + entry.getValue());
			}
		}
		
		else if(opcija.equalsIgnoreCase("IGNORE_CASE")){
			for(var putanja: this.listaIgnore){
				System.out.println(putanja);
			}
			
			for(Map.Entry<Path,Integer> entry: mapaIgnore.entrySet()){
				System.out.println(entry.getKey() + " -- " + entry.getValue());
			}
		}
		
		else{
			for(var putanja: this.listaLike){
				System.out.println(putanja);
			}
			
			for(Map.Entry<Path,Integer> entry: mapaLike.entrySet()){
				System.out.println(entry.getKey() + " -- " + entry.getValue());
			}
		}
	}
}