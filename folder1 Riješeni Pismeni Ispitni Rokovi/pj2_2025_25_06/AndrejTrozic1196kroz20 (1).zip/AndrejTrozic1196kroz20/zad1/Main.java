
import java.util.*;

public class Main{
	public static void main(String[] args){
		
		Hidrocentrala hidrocentrala = new Hidrocentrala();
		
		KontrolniModul kontrolniModul = new KontrolniModul(hidrocentrala);
		hidrocentrala.listaModula.add(kontrolniModul);
		ProizvodniModul proizvodniModul1 = new ProizvodniModul(hidrocentrala);
		hidrocentrala.listaModula.add(proizvodniModul1);
		ProizvodniModul proizvodniModul2 = new ProizvodniModul(hidrocentrala);
		hidrocentrala.listaModula.add(proizvodniModul2);
		DistributivniModul distributivniModul = new DistributivniModul(hidrocentrala, proizvodniModul1, proizvodniModul2);
		hidrocentrala.listaModula.add(distributivniModul);
		
		try{
			hidrocentrala.rijeka.start();
			for(var e:hidrocentrala.listaModula){
				e.start();
				// e.join();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		
	}
}