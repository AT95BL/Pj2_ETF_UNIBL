
public class DistributivniModul extends Modul{
	
	double kolicinaProizvedeneEnergije = 0;
	ProizvodniModul p1;
	ProizvodniModul p2;
	
	public DistributivniModul(){
		super();
	}
	
	public DistributivniModul(Hidrocentrala h){
		super(h);
	}
	
	public DistributivniModul(Hidrocentrala h, ProizvodniModul p1, ProizvodniModul p2){
		this.hidrocentrala = h;
		this.p1 = p1;
		this.p2 = p2;
	}
	
	@Override
	public void run(){
		while(true){
			try{
			System.out.println(this);
			System.out.println("Odrzavanje..");
			praznjenje(p1);
			praznjenje(p2);
			Thread.sleep(1000);
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}
	
	@Override
	public String toString(){
		return "Distributivni modul ..";
	}
	
	public void praznjenje(ProizvodniModul proizvodniModul){
		
		for(int i=0; i < proizvodniModul.skladiste.size(); i++){
			this.kolicinaProizvedeneEnergije += proizvodniModul.skladiste.get(i);
		}
		
		proizvodniModul.skladiste.clear();
		proizvodniModul.stanjeSkladista = 0;
	}
}