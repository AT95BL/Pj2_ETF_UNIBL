
import java.util.*;

public class Hidrocentrala{
	
	boolean radi;
	Rijeka rijeka = new Rijeka();
	
	List<Modul> listaModula = new ArrayList<>();
}