
public abstract class Modul extends Thread{
	
	Hidrocentrala hidrocentrala;
	
	public Modul(){
		
	}
	
	public Modul(Hidrocentrala h){
		this.hidrocentrala = h;
	}
	
	@Override
	public void run(){
		
	}
}