
import java.util.*;

public class Rijeka extends Thread{
	int nivo;
	Random random = new Random();
	
	public Rijeka(){
		this.nivo = random.nextInt(100)+1;
	}
	
	@Override
	public void run(){	

		while(true){
			System.out.println(this);
			
			if(nivo < 50){
				this.nivo = random.nextInt(50,100)+1;
			}
			
			try{
				Thread.sleep(3000);
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}
	
	@Override
	public String toString(){
		return "Rijeka tece..." + " " + " vodostaj: " + this.nivo;
	}
}