
import java.util.*;

public class KontrolniModul extends Modul{
	
	Scanner scanner = new Scanner(System.in);
	String line = "";
	
	public KontrolniModul(){
		super();
	}
	
	public KontrolniModul(Hidrocentrala h){
		super(h);
	}
	
	@Override
	public void run(){
		while(true){
			System.out.println(this);
			System.out.println("Odrzavanje..");
			System.out.println("Nivo vode: " + this.hidrocentrala.rijeka.nivo);
			try{
				Thread.sleep(5000);
			}catch(Exception ex){
				ex.printStackTrace();
			}
		
			System.out.println("Ovde kontrolni modul, da prekinem sve: Da/Ne");
			line = scanner.nextLine();
			if(line.equalsIgnoreCase("Da")){
				pritisniTaster();
			}else{
				System.out.println("Ok..");
			}
		}
	}
	
	public void paljenje(){
		this.hidrocentrala.radi = true;
	}
	
	public void gasenje(){
		this.hidrocentrala.radi = false;
	}
	
	@Override 
	public String toString(){
		return "Kontrolni modul..";
	}
	
	public void pritisniTaster(){
		System.exit(-1);
	}
}