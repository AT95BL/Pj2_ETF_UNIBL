
import java.util.*;

public class ProizvodniModul extends Modul{
	
	double kolicinaProizvedeneEnergije;
	List<Double> skladiste = new ArrayList<>();
	int stanjeSkladista = 0;
	
	public ProizvodniModul(){
		super();
	}
	
	public ProizvodniModul(Hidrocentrala h){
		super(h);
	}
	
	@Override
	public void run(){
		while(true){
			try{
			System.out.println(this);
			System.out.println("Odrzavanje..");
			Thread.sleep(1000);
			this.proizvediEnergiju();
			System.out.println("Stanje u skladistu: " + this.skladiste.size());
			System.out.println("Stanja: ");
			for(var d: this.skladiste){
				System.out.println(d);
			}
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}
	
	public void proizvediEnergiju(){
		this.kolicinaProizvedeneEnergije = this.hidrocentrala.rijeka.nivo / Math.sqrt(2);
		this.skladiste.add(kolicinaProizvedeneEnergije);
		this.stanjeSkladista++;
	}
	
	@Override
	public String toString(){
		return "Proizvodni modul..";
	}
}