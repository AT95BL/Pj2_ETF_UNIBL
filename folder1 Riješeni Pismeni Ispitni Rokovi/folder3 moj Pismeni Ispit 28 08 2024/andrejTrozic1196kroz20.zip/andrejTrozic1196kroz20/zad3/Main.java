
import java.util.*;
// import java.util.stream.*; // radi testiranja..

public class Main(){
	
	public static ArrayList<Student> kreirajListuStudenata1(){
		List<Student> studenti = new ArrayList<>();
		for(int i=0; i < 10; i++){
			Student student = new Student();
			studenti.add(student);
		}
		return studenti;
	}
	
	public static ArrayList<Student> kreirajListuStudenata2(){
		List<Student> studenti = new ArrayList<>();
		for(int i=10; i < 20; i++){
			Student student = new Student();
			studenti.add(student);
		}
		return studenti;
	}
	
	public static ArrayList<Student> kreirajListuStudenata3(){
		List<Student> studenti = new ArrayList<>();
		for(int i=10; i < 20; i++){
			Student student = new Student();
			studenti.add(student);
		}
		return studenti;
	}
	
	public static void main(String[] args){
		List<Student> studenti1 = kreirajListuStudenata1();
		List<Student> studenti2 = kreirajListuStudenata2();
		List<Student> studenti3 = kreirajListuStudenata3();
		
	}
}