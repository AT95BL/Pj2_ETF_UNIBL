
public interface Podatak{
	
}