
import java.util.Objects;

public class Student implements Podatak{
	public static int GLOBAL_ID;
	int id;
	
	String ime;
	String prezime;
	String brojIndeksa;
	
	// C
	public String(String ime, String prezime, String brojIndeksa){
		this.id = ++GLOBAL_ID;
		this.ime = "Ime" + this.id;
		this.prezime = "Prezime" + this.id;
		this.brojIndeksa = "BrojIndeksa" + this.id;
	}
	
	@Override
	public String toString(){
		return this.ime + " " + this.prezime + " " this.brojIndeksa;
	}
	
	@Override
	public boolean equals(Object obj){
		return Objects.equals(this.ime, ((Student)obj).ime) 
			&& Objects.equals(this.prezime, ((Student)obj).prezime)
			&& Objects.equals(this.brojIndeksa, ((Student)obj).brojIndeksa);
	}
	
	@Override
	public int hashCode(){
		return Objects.hash(ime, prezime, brojIndeksa);
	}
}