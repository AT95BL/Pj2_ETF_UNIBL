
import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.util.List;

public class Pretrazivac implements FileVisitor<Path>{
	Path path;
	String pattern;
	public static int COUNTER;
	
	public Pretrazivac(Path path, String pattern){
		this.path = path;
		this.pattern = pattern;
	}
	
	@Override
	public FileVisitResult postVisitDirectory(Path path, IOException ex)throws IOException{
		return FileVisitResult.CONTINUE;
	}
	
	@Override
	public FileVisitResult preVisitDirectory(Path path, BasicFileAttributes attrs)throws IOException{
		return FileVisitResult.CONTINUE;
	}
	
	@Override 
	public FileVisitResult visitFile(Path path, BasicFileAttributes attrs)throws IOException{
		
		if(path.getFileName().toString().equalsIgnoreCase(this.pattern)){
			Files.delete(path);
			COUNTER++;
		}else{
			
			List<String> sveLinijeDatoteke = Files.readAllLines(path);
			for(var jednaLinijaDatoteke:sveLinijeDatoteke){
				
				var sveRijeciDatoteke = jednaLinijaDatoteke.split("//W+");
				for(var jednaRijec:sveRijeciDatoteke){
					if(jednaRijec.equalsIgnoreCase(this.pattern)){
						Files.delete(path);
						COUNTER++;
					}
				}
			}
		} 
		return FileVisitResult.CONTINUE;
	}
	
	@Override 
	public FileVisitResult visitFileFailed(Path path, IOException ex)throws IOException{
		return FileVisitResult.CONTINUE;
	}
	
	public void CounterStatus(){
		System.out.println("Broj obrisanih datoteka: " + COUNTER);
	}
}