
import java.util.Scanner;
import java.io.*;
import java.nio.file.*;

public class Main{
	
	public static void main(String[] args){
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Unesite putanju: ");
		String line = scanner.nextLine();
		
		Path path = Paths.get(line);
		Pretrazivac pretrazivac = new Pretrazivac(path, line);
		
		try{
			Files.walkFileTree(path, pretrazivac);
		}catch(IOException ex){
			ex.printStackTrace();
		}
	}
}