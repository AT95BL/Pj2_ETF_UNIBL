
public interface Sonda{
	
}