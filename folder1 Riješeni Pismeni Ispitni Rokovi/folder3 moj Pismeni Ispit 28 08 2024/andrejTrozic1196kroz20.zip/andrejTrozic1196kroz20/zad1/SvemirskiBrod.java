
public class SvemirskiBrod extends SvemirskaLetjelica implements NavigacijskiSistem, EnergetskiStit{
	public static boolean SMJER_KRETANJA = true;
	Raketa raketa;
	Laser laser;
	
	// C
	public SvemirskiBrod(int x, int y){
		super(x, y, SMJER_KRETANJA);
		
		this.raketa = new Raketa();
		this.laser = new Laser();
	}
}