
public interface EnergetskiStit{
	
}