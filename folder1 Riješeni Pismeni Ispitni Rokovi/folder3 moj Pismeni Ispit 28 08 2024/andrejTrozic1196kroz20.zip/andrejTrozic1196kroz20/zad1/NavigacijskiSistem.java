
public interface NavigacijskiSistem{
	
}