
import java.util.Random;

public class Laser{
	int snaga;
	Random random = new Random();
	// C
	public Laser(){
		this.snaga = random.nextInt();
	}
}