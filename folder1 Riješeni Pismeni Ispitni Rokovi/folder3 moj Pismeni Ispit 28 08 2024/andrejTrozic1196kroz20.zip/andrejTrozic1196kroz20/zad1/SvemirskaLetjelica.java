
import java.util.Random;
import java.util.Date;

public abstract class SvemirskaLetjelica extends Thread{
	Random random = new Random();
	public static Object stLock = new Object();
	public static int GLOBAL_ID;
	int id;
	
	int koordinataX;
	int koordinataY;
	boolean smjerKretanja;
	boolean unisten=false;
	boolean dosegaoKrajMape=false;
	
	long startTime;
	long endTime;
	
	// C
	public SvemirskaLetjelica(int x, int y, boolean smjerKretanja){
		this.koordinataX=x;
		this.koordinataY=y;
		this.smjerKretanja=smjerKretanja;
		
		Simulacija.mapa[x][y] = this;
	}
	
	@Override
	public void run(){
		
		this.startTime = new Date().getTime();
		
		while(true){
			
			this.endTime = new Date().getTime();
			
			System.out.println(this);
			
			if(this.unisten || this.dosegaoKrajMape){
				System.out.println(this + " KRAJ!");
				return;
			}
			
			if(Simulacija.pauzaPokrenuta){
				synchronized(Simulacija.pauzaLock){
					try{
						Simulacija.pauzaLock.wait();
					}catch(InterruptedException ex){
						ex.printStackTrace();
					}
				}
			}
			
			// kretanje
			if(this.smjerKretanja == true){
				synchronized(stLock){
					
					if(this.koordinataY == Simulacija.BROJ_KOLONA-1){
						this.dosegaoKrajMape=true;
						return;
					}
					
					if(Simulacija.mapa[this.koordinataX][this.koordinataY+1] != null){
						System.out.println("Borba je u toku!!");
					}
					
					this.koordinataY++;
					Simulacija.mapa[this.koordinataX][this.koordinataY] = this;
					Simulacija.mapa[this.koordinataX][this.koordinataY-1] = null;
					
					if(this.koordinataY == Simulacija.BROJ_KOLONA-1){
						this.dosegaoKrajMape=true;
					}
				}
			}else if(this.smjerKretanja == false){
				synchronized(stLock){
					
					if(this.koordinataY == 0){
						this.dosegaoKrajMape=true;
						return;
					}
					
					if(Simulacija.mapa[this.koordinataX][this.koordinataY-1] != null){
						System.out.println("Borba je u toku!!");
					}
					
					this.koordinataY--;
					Simulacija.mapa[this.koordinataX][this.koordinataY] = this;
					Simulacija.mapa[this.koordinataX][this.koordinataY+1] = null;
					
					if(this.koordinataY == 0){
						this.dosegaoKrajMape=true;
					}
				}
			}
			
			try{
				Thread.sleep(1000);
			}catch(InterruptedException ex){
				ex.printStackTrace();
			}
		}
	}
	
	@Override
	public String toString(){
		return "ID: " + this.id + "\n" +
		"(" + this.koordinataX + "," + this.koordinataY + ")";
	}
}