

public class BespilotnaLetjelica extends SvemirskaLetjelica implements Senzor, Sonda{
	public static boolean SMJER_KRETANJA = false;
	Laser laser;
	
	// C
	public BespilotnaLetjelica(int x, int y){
		super(x, y, SMJER_KRETANJA);
		
		this.laser = new Laser();
	}
}