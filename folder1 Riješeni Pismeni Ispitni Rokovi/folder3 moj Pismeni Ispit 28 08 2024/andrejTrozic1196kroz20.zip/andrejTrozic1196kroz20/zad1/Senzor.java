
public interface Senzor{
	
}