
import java.util.*;

public class Raketa{
	int x;
	int y;
	Random random = new Random();
	
	// C
	public Raketa(){
		this.x = random.nextInt(20);
		this.y = random.nextInt(40);
	}
}