
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class Simulacija{
	Random random = new Random();
	public static final int BROJ_VRSTA = 3;
	public static final int BROJ_KOLONA = 40;
	
	public static Object[][] mapa;
	public static Object pauzaLock = new Object();
	public static Object lock = new Object();
	public static boolean pauzaPokrenuta = false;
	public static ArrayList<SvemirskaLetjelica> letjelice = new ArrayList<>();
	
	// C
	public Simulacija(){
		this.mapa = new Object[BROJ_VRSTA][BROJ_KOLONA];
		kreirajListuSvemirskihLetjelica();
	}
	
	public void kreirajListuSvemirskihLetjelica(){
		
		SvemirskiBrod sb = new SvemirskiBrod(random.nextInt(BROJ_VRSTA), random.nextInt(BROJ_KOLONA));
		letjelice.add(sb);
		
		MatricnaStanica ms = new MatricnaStanica(random.nextInt(BROJ_VRSTA), random.nextInt(BROJ_KOLONA));
		letjelice.add(ms);
		
		BespilotnaLetjelica bl1 = new BespilotnaLetjelica(random.nextInt(BROJ_VRSTA), random.nextInt(BROJ_KOLONA));
		letjelice.add(bl1);
		BespilotnaLetjelica bl2 = new BespilotnaLetjelica(random.nextInt(BROJ_VRSTA), random.nextInt(BROJ_KOLONA));
		letjelice.add(bl2);
	}
	
	public void pokreniSimulaciju(){
		for(var svemirskaLetjelica:letjelice){
			svemirskaLetjelica.start();
		}
	}
	
	public static void main(String[] args){
		Simulacija simulacija = new Simulacija();
		simulacija.pokreniSimulaciju();
		
		Scanner scanner = new Scanner(System.in);
		String line = "Pj2";
		
		try{
			while(!line.equalsIgnoreCase("END")){
				line = scanner.nextLine();
				
				if(line.equalsIgnoreCase("WAIT")){
					Simulacija.pauzaPokrenuta=true;
				}
				else if(line.equalsIgnoreCase("NOTIFY")){
					Simulacija.pauzaPokrenuta=false;
					Simulacija.pauzaLock.notifyAll();
				}
				else if(line.equalsIgnoreCase("INFO")){
					synchronized(lock){
						for(var letjelica:letjelice){
							System.out.println(letjelica);
						}
					}
				}
				else if(line.equalsIgnoreCase("INFO")){
					synchronized(lock){
						for(var letjelica:letjelice){
							System.out.println(letjelica + "\nTime: " + (letjelica.endTime - letjelica.startTime));
						}
					}
				}
				
				else{
					throw new CommandNotValidException("Command Not Valid Exception");
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}