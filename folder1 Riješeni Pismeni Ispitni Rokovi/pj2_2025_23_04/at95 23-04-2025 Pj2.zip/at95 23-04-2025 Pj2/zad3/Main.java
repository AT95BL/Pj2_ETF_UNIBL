
import java.util.*;
import java.util.stream.*;
import java.util.function.Function;

public class Main{
	public static void main(String[] args){
		
		Set<Film> grupaFilmova = new HashSet<>();
		for(int i=0; i < 100; i++){
			grupaFilmova.add(new Film());
		}
		
		grupaFilmova.stream().forEach(System.out::println);
		
		// 1
		grupaFilmova.stream().sorted(Comparator.comparingDouble(Film::getProsjecnaOcjena)).forEach(System.out::println);
		var prosjek = grupaFilmova.stream().mapToDouble(Film::getProsjecnaOcjena).average();
		System.out.println("Prosjecna ocjena: " + prosjek.getAsDouble());
		
		// 2
		var pom1 = grupaFilmova.stream().filter((film)->film.prosjecnaOcjena > prosjek.getAsDouble()).mapToDouble(Film::getProsjecnaOcjena).average();
		var pom2 = grupaFilmova.stream().filter((film)->film.prosjecnaOcjena > prosjek.getAsDouble()).collect(Collectors.counting());
		
		try{
			System.out.println(pom2/pom1.getAsDouble());
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		// 3
		grupaFilmova.stream().collect(Collectors.groupingBy(Film::getGodinaIzdanja)).forEach((godina, filmovi)->{
			System.out.println(godina + ": ");
			filmovi.forEach(System.out::println);
		});
		
		// 4
		Function<Film, Integer> funkcija = (film)->{
			if(film.zanr.equals(Zanr.NAUCNA_FANTASTIKA) && film.godinaIzdanja % 2 == 0){
				return film.godinaIzdanja;
			}
			return 0;
		};
		
		long trajanje = grupaFilmova.stream().filter(film->funkcija.apply(film) != 0).mapToInt(Film::getTrajanje).sum();
		System.out.println("Trajanje: " + trajanje);
		
		// 5
		grupaFilmova.stream().min(Comparator.comparingInt(Film::getTrajanje)).ifPresent(System.out::println);
		grupaFilmova.stream().max(Comparator.comparingInt(Film::getTrajanje)).ifPresent(System.out::println);
		var prosjekTrajanja = grupaFilmova.stream().mapToInt(Film::getTrajanje).average();
		System.out.println("Prosjek trajanja: " + prosjekTrajanja.getAsDouble());
		grupaFilmova.stream().filter(film->film.trajanje == prosjekTrajanja.getAsDouble()).forEach(System.out::println);
	}
}