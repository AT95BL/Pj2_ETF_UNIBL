
public enum Zanr{
	AKCIJA,
	KOMEDIJA,
	DRAMA,
	HOROR,
	NAUCNA_FANTASTIKA
}