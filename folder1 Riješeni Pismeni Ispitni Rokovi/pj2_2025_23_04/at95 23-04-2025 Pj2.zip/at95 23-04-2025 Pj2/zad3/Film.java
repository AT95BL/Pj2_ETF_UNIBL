
import java.util.Objects;
import java.util.Random;

public class Film{
	String naslov;
	String reziser;
	Zanr zanr;
	int trajanje;
	double prosjecnaOcjena;
	int godinaIzdanja;
	
	Random random = new Random();
	
	public static int ID=0;
	int id;
	
	// Constructor
	public Film(){
		this.id = ++ID;
		this.naslov = "naslov"+this.id;
		this.reziser = "reziser"+this.id;
		this.zanr = Zanr.values()[this.id % 5];
		this.trajanje = 60 + (this.id % 5);
		this.prosjecnaOcjena = random.nextDouble(10)+1;
		this.godinaIzdanja = 1990 + this.id%5;
	}
	
	@Override
	public boolean equals(Object obj){
		if(obj == null || obj.getClass() != this.getClass()){
			return false;
		}
		
		if(obj == this){
			return true;
		}
		
		Film film = (Film)obj;
		return this.naslov.equals(film.naslov) && this.reziser.equals(film.reziser) && this.zanr.equals(film.zanr);
	}
	
	@Override
	public int hashCode(){
		return Objects.hash(this.naslov, this.reziser, this.zanr);
	}
	
	@Override
	public String toString(){
		return this.naslov + " " + this.reziser + " " + this.zanr + " " + this.trajanje + " " + this.prosjecnaOcjena + " " + this.godinaIzdanja;
	}
	
	public double getProsjecnaOcjena(){
		return this.prosjecnaOcjena;
	}
	
	public int getGodinaIzdanja(){
		return this.godinaIzdanja;
	}
	
	public int getTrajanje(){
		return this.trajanje;
	}
}