
import java.util.*;
import java.io.*;
import java.nio.file.*;

public class Main{
	
	public static void main(String[] args){
		
		Scanner scanner = new Scanner(System.in);
		String line;
		
		List<String> sveLinijeDatotekeItems = null;
		System.out.println("Unesite putanju do datoteke 'Items.csv': ");
		line = scanner.nextLine();
		Path putanjaDoItemsDatoteke = Paths.get(line);
		try{
			sveLinijeDatotekeItems = Files.readAllLines(putanjaDoItemsDatoteke);
		}catch(IOException ex){
			ex.printStackTrace();
		}
		
		boolean prvaLinijaDatotekeItems=false;
		List<Item> itemsList = new ArrayList<>(); 
		for(String jednaLinijaDatotekeItems:sveLinijeDatotekeItems){
			
			String[] linijaDatoteke = jednaLinijaDatotekeItems.split(",");
			
			if(!prvaLinijaDatotekeItems){
				prvaLinijaDatotekeItems=true;
				continue;
			}
			
			String warehouse = linijaDatoteke[0];
			int articleId = Integer.parseInt(linijaDatoteke[1]);
			String articleName = linijaDatoteke[2];
			String category = linijaDatoteke[3];
			int quantity = Integer.parseInt(linijaDatoteke[4]);
			int period = Integer.parseInt(linijaDatoteke[5]);
			
			Item item = new Item(warehouse, articleId, articleName, category, quantity, period);
			itemsList.add(item);
		}
		
		boolean prvaLinijaDatotekeCommands=false;
		List<String> sveLinijeDatotekeCommands = null;
		System.out.println("Unesite putanju do datoteke 'Commands.csv': ");
		line = scanner.nextLine();
		Path putanjaDoCommandsDatoteke = Paths.get(line);
		try{
			sveLinijeDatotekeCommands = Files.readAllLines(putanjaDoCommandsDatoteke);
		}catch(IOException ex){
			ex.printStackTrace();
		}
		
		List<Command> commandsList = new ArrayList<>();
		for(String jednaLinijaDatotekeCommands: sveLinijeDatotekeCommands){
			
			String[] linijaDatoteke = jednaLinijaDatotekeCommands.split(",");
			
			if(!prvaLinijaDatotekeCommands){
				prvaLinijaDatotekeCommands=true;
				continue;
			}
			
			String operation = linijaDatoteke[0];
			String source = linijaDatoteke[1];
			String destination = linijaDatoteke[2];
			int articleId = Integer.parseInt(linijaDatoteke[3]);
			int quantity = Integer.parseInt(linijaDatoteke[4]);
			
			Command komanda = new Command(operation, source, destination, articleId, quantity);
			commandsList.add(komanda);
		}
		
		Warehouse w1 = new Warehouse("A");
		Warehouse w2 = new Warehouse("B");
		Warehouse w3 = new Warehouse("C");
		
		List<Warehouse> warehouseList = new ArrayList<>();
		warehouseList.add(w1);
		warehouseList.add(w2);
		warehouseList.add(w3);
		
		w1.start();
		w2.start();
		w3.start();
		
		Random random = new Random();
		
		for(var komanda:commandsList){
			if(komanda.operation.equals("add")){
				for(var w: warehouseList){
					if(w.warehouseName.equals(komanda.source)){
						w.addItem(itemsList.get(random.nextInt(itemsList.size())));
					}
				}
			}
			else if(komanda.operation.equals("move")){
				for(var w: warehouseList){
					if(w.warehouseName.equals(komanda.source)){
						w.moveItem(warehouseList.get(random.nextInt(warehouseList.size())));
					}
				}
			}
		}	
	}
}