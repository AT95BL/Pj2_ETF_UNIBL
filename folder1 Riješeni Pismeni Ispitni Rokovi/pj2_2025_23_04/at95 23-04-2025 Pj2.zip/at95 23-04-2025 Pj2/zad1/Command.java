
public class Command{
	
	String operation;
	String source;
	String destination;
	int articleId;
	int quantity;
	
	// Constructor
	public Command(
		String operation,
		String source,
		String destination,
		int articleId,
		int quantity){
		this.operation = operation;
		this.source = source;
		this.destination = destination;
		this.articleId = articleId;
		this.quantity = quantity;
	}
}