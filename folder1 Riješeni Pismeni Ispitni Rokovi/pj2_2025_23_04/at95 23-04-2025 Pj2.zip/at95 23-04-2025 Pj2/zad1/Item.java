
public class Item{
	String warehouse;
	int articleId;
	String articleName;
	String category;
	int quantity;
	int period;
	
	// Constructor
	public Item(
		String warehouse,
		int articleId,
		String articleName,
		String category,
		int quantity,
		int period
	){
		this.warehouse = warehouse;
		this.articleId = articleId;
		this.articleName = articleName;
		this.category = category;
		this.quantity = quantity;
		this.period = period;
	}
}