
import java.util.*;

public class Warehouse extends Thread{
	String warehouseName;
	Random random = new Random();
	List<Item> items = new ArrayList<>();
	
	public Warehouse(String warehouseName){
		this.warehouseName = warehouseName;
	}
	
	public void addItem(Item item){
		this.items.add(item);
		System.out.println(this.warehouseName + "dodavanje..");
	}
	
	public void moveItem(Warehouse w){
		w.items.add(this.items.get(random.nextInt(items.size())));
		System.out.println(this.warehouseName + "prebacivanje u " + w.warehouseName + "..");
	}
	
	@Override
	public void run(){
		
		try{
			Thread.sleep(1000);
		}catch(InterruptedException ex){
			ex.printStackTrace();
		}
		
		System.out.println(this.warehouseName);
	}
}