
import java.util.*;
import java.io.*;
import java.nio.file.*;

public class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Unesite putanju pocetnog direktorijuma: ");
		String line = scanner.nextLine();
		Path pocetnaPutanja = Paths.get(line);
		
		FileFinder fileFinder = new FileFinder(pocetnaPutanja);
		
		try{
			Files.walkFileTree(pocetnaPutanja, fileFinder);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		fileFinder.function();
	}
}