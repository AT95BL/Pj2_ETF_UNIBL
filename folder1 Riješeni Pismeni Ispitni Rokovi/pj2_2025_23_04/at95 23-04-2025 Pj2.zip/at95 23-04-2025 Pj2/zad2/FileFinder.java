import java.util.*;
import java.io.*;
import java.nio.file.*;
import  java.nio.file.attribute.*;

public class FileFinder implements FileVisitor<Path>{
	
	Map<Character, Character> mapa = new HashMap<>();
	
	Path putanjaPocetnogDirektorijuma;
	List<Path> putanje = new ArrayList<>();
	List<String> sadrzaji = new ArrayList<>();
	
	// Constructor
	public FileFinder(Path putanjaPocetnogDirektorijuma){
		this.putanjaPocetnogDirektorijuma = putanjaPocetnogDirektorijuma;
	}
	
	@Override
	public FileVisitResult postVisitDirectory(Path dir, IOException exc)throws IOException{
		return FileVisitResult.CONTINUE;
	}
	
	@Override	
	public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException{
		return FileVisitResult.CONTINUE;
	}
	
	@Override
	public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException{
		
		this.putanje.add(file);
		
		return FileVisitResult.CONTINUE;
	}
	
	@Override
	public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException{
		return FileVisitResult.CONTINUE;
	}
	
	public void function(){
		for(int i=0; i < this.putanje.size(); i++){
			
			if(this.putanje.get(i) == null){
				continue;
			}
			
			List<String> sveLinijeDatoteke1 = null;
			List<String> sveLinijeDatoteke2 = null;
			
			try{
				sveLinijeDatoteke1 = Files.readAllLines(this.putanje.get(i));
			}catch(Exception ex){
				ex.printStackTrace();
			}
			
			for(int j=1; j < this.putanje.size()-1; j++){
				
				if(this.putanje.get(j) == null){
					continue;
				}	
				
				try{
					sveLinijeDatoteke2 = Files.readAllLines(this.putanje.get(j));
				}catch(Exception ex){
					ex.printStackTrace();
				}
				
				if(sveLinijeDatoteke1.equals(sveLinijeDatoteke2)){
					try{
						Files.delete(this.putanje.get(j));
					}catch(Exception ex){
						ex.printStackTrace();
					}
				}
			}
				
		}
	}
	
	public void ispuniMapu(){
		mapa.put('Q','Љ');
		mapa.put('W','Њ');
		mapa.put('E','Е');
		mapa.put('R','Р');
		mapa.put('T','Т');
		mapa.put('Y','З');
		mapa.put('U','У');
		mapa.put('I','И');
		mapa.put('O','О');
		mapa.put('P','П');
		mapa.put('A','А');
		mapa.put('S','С');
		mapa.put('D','Д');
		mapa.put('F','Ф');
		mapa.put('G','Г');
		mapa.put('H','Х');
		mapa.put('J','Ј');
		mapa.put('K','К');
		mapa.put('L','Л');
		mapa.put('Z','Ѕ');
		mapa.put('X','Џ');
		mapa.put('C','Ц');
		mapa.put('V','В');
		mapa.put('B','Б');
		mapa.put('N','Н');
		mapa.put('M','М');
		
		mapa.put('q','љ');
		mapa.put('w','њ');
		mapa.put('e','е');
		mapa.put('r','р');
		mapa.put('t','т');
		mapa.put('y','з');
		mapa.put('u','у');
		mapa.put('i','и');
		mapa.put('o','о');
		mapa.put('p','п');
		mapa.put('a','а');
		mapa.put('s','с');
		mapa.put('d','д');
		mapa.put('f','ф');
		mapa.put('g','г');
		mapa.put('h','х');
		mapa.put('j','ј');
		mapa.put('k','к');
		mapa.put('l','л');
		mapa.put('z','ѕ');
		mapa.put('x','џ');
		mapa.put('c','ц');
		mapa.put('v','в');
		mapa.put('b','б');
		mapa.put('n','н');
		mapa.put('m','м');
	}
}
